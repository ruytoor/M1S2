ALLART_RUYTOOR

tout fonctionne

nous avions eu du mal pour la question 1 (la multiplication de matrice) on a tout fait à la main.

