/**

  @author F. Aubert
  **/

#include "Square.h"

#include <iostream>

using namespace std;


/**
  Initialisation des buffers pour le carré
*/
void Square::initBuffer() {
  // TODO
  // float vertex[]={x0,y0,z0,x1,y1,z1,x2,y2,z2, etc}


}

/**
  Tracé par buffer du carré
*/
void Square::drawBuffer() {
  // TODO

}


Square::Square() {
  _idTexture.resize(3);
  _bufferTexCoord.resize(3);
}

Square::~Square(){
}

void Square::texture(unsigned int unite,GLuint id) {
  _idTexture[unite]=id;
}



