#ifndef GLSUPPORT_H
#define GLSUPPORT_H

#include <GL/glew.h>

#include <QGLWidget>
#include <GL/glu.h>


#endif // GLSUPPORT_H
